import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav style={{ display: "flex", gap: "1rem", justifyContent: "center" }}>
      <Link to="/">Home</Link>
      <Link to="/search">Search</Link>
      <Link to="/character">Character Builder</Link>
      <Link to="/music">Music</Link>
    </nav>
  );
}
