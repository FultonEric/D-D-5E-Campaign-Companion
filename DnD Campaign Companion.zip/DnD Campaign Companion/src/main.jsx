import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import App from "./App.jsx";
import SearchSection from "./Components/SearchSection.jsx";
//import CharacterBuilder from "./pages/CharacterBuilder.jsx";
//import MusicMixer from "./pages/MusicMixer.jsx";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/search" element={<SearchSection />} />

    </Routes>
  </BrowserRouter>
);

